#include <stdio.h>

int f6() {
	printf("Hello, I'm from the second dynamic library! :)\n");
}