#include <stdio.h>
void f2() {
	printf("Hello, I'm from static library! :)\n");
}