int f1() {
	return 76;
}