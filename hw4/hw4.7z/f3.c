#include <stdio.h>

void f3() {
	printf("Hello, I'm from dynamic library! :)\n");
}