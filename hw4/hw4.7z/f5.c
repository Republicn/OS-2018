int f5() {
	return 4;
}